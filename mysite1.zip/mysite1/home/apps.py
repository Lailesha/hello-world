from django.apps import AppConfig


class Personal1Config(AppConfig):
    name = 'home'
