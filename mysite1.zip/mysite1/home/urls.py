from django.conf.urls import url,include
from . import views

urlpatterns = [
	url(r'^$', views.index, name='index'),
	url(r'^contact/', views.contact, name='contact'),
	url(r'^service/', views.service, name='service'),
	url(r'^about/', views.about, name='about'),
	url(r'^output/', views.output, name='output'),
	url(r'^output1/', views.output1, name='output1'),
	url(r'^menu/', views.menu, name='menu'),
	url(r'^designing/', views.designing, name='designing'),
	url(r'^wheeler_service/', views.wheeler_service, name='wheeler_service'),
	url(r'^goods_carrier/', views.goods_carrier, name='goods_carrier'),
	url(r'^design_confirm/', views.design_confirm, name='design_confirm'),
]
