from django import forms

class NameForm(forms.Form):
			current_id = forms.CharField(label='Employee Id', max_length=100)
			employee_name = forms.CharField(label='Employee Name', max_length=100)
			employee_email_address = forms.CharField(label='Employee Email Address', max_length=100)
			employee_password = forms.CharField(label='Employee Password', max_length=100)
			employee_salary = forms.CharField(label='Employee Salary', max_length=100)
