from django.conf.urls import include
from django.shortcuts import render
from django.template import RequestContext, Template

from django.http import HttpResponseRedirect, HttpResponse

from .forms import NameForm

def index(request):
    return render(request, 'home/index.html')
def contact(request):
    return render(request, 'home/contact.html')
def service(request):
    return render(request, 'home/service.html')

def about(request):
    return render(request, 'home/about.html')
def designing(request):
    return render(request, 'home/designing.html')
def wheeler_service(request):
    return render(request, 'home/wheeler_service.html')
def goods_carrier(request):
    return render(request, 'home/goods_carrier.html')

def output(request):
	import MySQLdb
	con = MySQLdb.connect("localhost", "root", "Latitude@e5450Ll", "srcollege")
	cur = con.cursor();
	cur1 = con.cursor();
	u = request.POST['username']
	e = request.POST['email']
	p = request.POST['password']
	cp = request.POST['cpassword']
	if (p == cp):
		sql = "insert into registerlogin values ('" + u + "', '" + e + "', '" + p + "', '" + cp + "');"
		cur.execute(sql)
		file = open("home/templates/home/output.html", "w")
		file.write("<html><head><title>Registered successfully!!!!</title></head><body><h3>Registered successfully!!!! <br/><a href=\"{% url 'index' %}\">Login here</a></h3>")
		file.write("<table border=\"1\" width=\"100%\"><tbody>")
		sql1 = "select * from registerlogin;"
		cur1.execute(sql1)
		for row in cur1.fetchall():
			file.write("<tr><td>")
			file.write(str(row[0]))
			file.write("</td>")
			file.write("<td>")
			file.write(str(row[1]))
			file.write("</td>")
			file.write("<td>")
			file.write(str(row[2]))
			file.write("</td>")
			file.write("<td>")
			file.write(str(row[3]))
			file.write("</td></tr>")
			
		file.write("</tbody></table></body></html>")
		con.autocommit(True)
		file.close()
		return render(request, 'home/output.html')
	else:
		file = open("home/templates/home/output.html", "w")
		file.write("<html><head><title>Error in Register</title></head><body><h3>Error in Register</h3><p><a href=\"{% url 'index' %}\">Back to Home</a></p>")
		file.write("</body></html>")
		file.close()
		return render(request, 'home/output.html')
		

def output1(request):
	import MySQLdb
	con = MySQLdb.connect("localhost", "root", "Latitude@e5450Ll", "srcollege")
	cur1 = con.cursor();
	u = request.POST['username1']
	e = request.POST['password1']
	print(u)
	print(e)
	sql = "select count(*) from registerlogin where username = '" + u + "' and password = '" + e + "';"
	res = cur1.execute(sql)
	for result in cur1.fetchall():
		print(result)
		if result[0] > 0:
			file = open("home/templates/home/output1.html", "w")
			file.write("<html><head><title>Login is sucessful</title></head><body><h3>Login successfully!!!! <br/><a href=\"{% url 'index' %}\">Login here</a></h3><p>")
			file.write("</p><p><a href=\"{% url 'menu' %}\">Click for Menu</a></p></body></html>")
			file.close()
			return render(request, 'home/output1.html')
		else:
			file = open("home/templates/home/output1.html", "w")
			file.write("<html><head><title>Error in Login</title></head><body><h3>Error in Login</h3><p><a href=\"{% url 'index' %}\">Back to Home</a></p>")
			file.write("</body></html>")
			file.close()
			return render(request, 'home/output1.html')

def menu(request):
    return render(request, 'home/menu.html')

def design_confirm(request):
	print("hi")
	return render(request, 'home/design_confirm.html')